package com.in28minutes.mockito;

import static org.junit.Assert.*;

import org.junit.Test;

//TodoService.java => Wunderlist
//public List<String> retrieveTodos(String user);
//


//TodoBusinessImpl.java
//public List<String> retrieveTodosRelatedToSpring(String user)

public class FirstMockitoTest {

	@Test
	public void test() {
		assertTrue(true);
	}
}
